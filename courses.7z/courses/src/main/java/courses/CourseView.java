package courses;

public record CourseView(String code, String name) {

}
