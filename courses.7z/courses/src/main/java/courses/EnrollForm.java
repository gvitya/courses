package courses;

public record EnrollForm(String courseCode, String name) {


}
